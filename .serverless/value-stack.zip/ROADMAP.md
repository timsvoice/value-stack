##11/04
So we have a functioning graphql + serverless prototype. Today we're going to integrate a dynamoDB reference. We'll start by uploading some data from FanDual, creating the appropriate graphql resolver function, then displaying some of that data in the client.

Right now we dont care about styles. Probaly will use the Material React Library for ease of use. This will be good practice for the Hackathon.

Bonus points:
Add @param tags to all export functions!
