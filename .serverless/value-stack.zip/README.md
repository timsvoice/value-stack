# value-stack
An app that ranks FanDual NFL players according to their value
